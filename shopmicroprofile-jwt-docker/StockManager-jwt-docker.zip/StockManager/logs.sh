#!/bin/sh
docker logs StockManager -f