
/**
 * Restful services here
 */
package myproject.stockmanager.service;