#!/bin/sh
docker logs ProductCatalogue -f