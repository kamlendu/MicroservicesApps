
/**
 * Restful services here
 */
package myproject.productcatalogue.service;