#!/bin/sh
docker logs ShopFront -f