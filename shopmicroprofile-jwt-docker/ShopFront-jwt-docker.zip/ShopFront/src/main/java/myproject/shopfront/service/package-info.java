
/**
 * Restful services here
 */
package myproject.shopfront.service;