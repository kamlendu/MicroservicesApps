
/**
 * Restful services here
 */
package event.microservices.msaclientapp.service;