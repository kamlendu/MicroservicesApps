#!/bin/sh
docker logs MSAClientApp -f