
/**
 * Restful services here
 */
package event.microservices.samplemicroprofileapp.service;