#!/bin/sh
docker logs SampleMicroProfileApp -f